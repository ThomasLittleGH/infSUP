/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilas;

import java.util.Scanner;
import java.util.Stack;

/**
 * push: introduce datos
 * pop: muetra y borra el último dato
 * peek: muestra el último dato
 * empty: pregunta si existen valores en la pila
 * 
 * @author Lab
 */
public class Pilas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // FILO
        Stack pila = new Stack();
        pila.push(14);
        pila.push("texto");
        pila.push(true);
        pila.push('x');
        pila.push(1.1);
        pila.push(null);
        
        System.out.println("Pila: " + pila);
        
        System.out.println("Buscar valor en pila (14): " + pila.search(14)); // Cuenta el valor de arriba a abajo
        
        System.out.println("Último valor (y lo elimina): " + pila.pop());
        
        System.out.println("Nuevo ultimo valor: " + pila.peek());
        
        System.out.println("Pila: " + pila);
        
        while(!pila.empty()){
            System.out.println("Elimino el último dato hasta vaciar la fila: " + pila.pop());
        }
        
        System.out.println("Pila: " + pila);
        
        // Ejercicio 1
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese Palindromo a revisar");
        String input = teclado.next();
        
        for (char c : input.toCharArray()) {
            pila.push(c);
        }
        
        String output = "";
        
        while(!pila.empty()){
            output = output + pila.pop();
        }
        
        if (input.equals(output)) {
            System.out.println("PALINDROMO");
        } else {
            System.out.println("NO ES PALINDROMO");
        }
    }
    
}
